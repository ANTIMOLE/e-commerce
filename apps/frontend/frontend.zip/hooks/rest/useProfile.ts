"use client";
// TODO: implementasi lengkap
export function useProfile() { throw new Error("belum diimplementasi"); }
